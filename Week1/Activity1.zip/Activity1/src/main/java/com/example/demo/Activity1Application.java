package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Activity1Application {

	public static void main(String[] args) {
		System.out.println("Hello from my spring boot applicaiton");
		SpringApplication.run(Activity1Application.class, args);
	}

}
